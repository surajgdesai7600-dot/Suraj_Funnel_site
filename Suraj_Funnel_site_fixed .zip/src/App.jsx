import React from "react";

function App() {
  return (
    <div className="app">
      <h1>Suraj's Funnel Analysis Portfolio</h1>
      <p>Subscription SaaS Funnel Analysis Dashboard</p>
    </div>
  );
}

export default App;